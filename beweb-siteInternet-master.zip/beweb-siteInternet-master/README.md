# beweb-siteInternet
Depot temporaire du site de beweb

partie 1 :
mise en place de du format de données html / avec les informations présentes
